import { createContext } from 'react'

export const AnalyticsContext = createContext()

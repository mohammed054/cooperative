/**
 * About — Scene 3  (FULL REWRITE)
 * ───────────────────────────────────────────────────────────────
 * Philosophy: This is no longer a "section". It's a sequence of moments.
 *
 * ARCHITECTURE:
 *   Part 1 — Image Reveal    (natural scroll, ~viewport height)
 *             Full-width clip-path expansion. The visual statement.
 *
 *   Part 2 — Pinned Editorial  (sticky frame, ~340vh scroll travel)
 *             A locked scene. User has to scroll THROUGH it.
 *             Nothing appears until earned. Each reveal is deliberate.
 *
 *             Phase A (0–18%):   Eyebrow line materialises
 *             Phase B (14–32%):  Headline line 1 — "Where Vision Meets"
 *             Phase C (26–44%):  Headline line 2 — "Flawless Execution." (punchline)
 *             Phase D (40–56%):  Gold rule extends
 *             Phase E (52–66%):  Body paragraph 1
 *             Phase F (62–74%):  Body paragraph 2
 *             Phase G (70–80%):  Pillar 01 — "A quiet approach."
 *             Phase H (78–87%):  Pillar 02 — "Precision over performance."
 *             Phase I (85–94%):  Pillar 03 — "Legacy over landmark."
 *             Phase J (91–100%): CTA arrow link appears
 *
 *   Part 3 — Client Marquee  (natural scroll, after pin releases)
 *
 * MOTION RULES:
 *   All reveals: y: 32 → 0, opacity: 0 → 1, filter: blur(6px) → blur(0)
 *   Headline line 2 gets scale: 0.97 → 1.0 for extra weight
 *   Pillars: y: 40 → 0, staggered by phase (not simultaneous)
 *   Scrub: 1.4 — slightly over-damped for maximum control feel
 *
 * LAYOUT:
 *   Desktop: 45% left (headline) / 55% right (content phases)
 *   Mobile:  no pin, stacked layout, natural animation
 */

import { useEffect, useRef } from 'react';
import { motion }      from 'framer-motion';
import { gsap }        from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

/* ── Data ─────────────────────────────────────────────────────── */

const CLIENTS = [
  'MAG Group', 'Emaar Properties', 'DIFC Authority',
  'Dubai Holding', 'Meraas', 'Aldar Properties',
  'MAG Group', 'Emaar Properties', 'DIFC Authority',
  'Dubai Holding', 'Meraas', 'Aldar Properties',
];

const PILLARS = [
  {
    number: '01',
    title: 'A quiet approach.',
    body: "We don't seek attention for ourselves. The event is the statement. Our role is invisible architecture — the reason everything feels inevitable.",
  },
  {
    number: '02',
    title: 'Precision over performance.',
    body: "Execution is not measured in headcount or decibels. It's measured in the quality of conversation the morning after.",
  },
  {
    number: '03',
    title: 'Legacy over landmark.',
    body: "Any venue can impress once. We design experiences that compound — that become reference points in the memory of everyone in the room.",
  },
];

/* ── Logo marquee ─────────────────────────────────────────────── */

function LogoMarquee() {
  return (
    <div
      style={{
        overflow: 'hidden',
        maskImage: 'linear-gradient(to right, transparent, black 12%, black 88%, transparent)',
        WebkitMaskImage: 'linear-gradient(to right, transparent, black 12%, black 88%, transparent)',
      }}
    >
      <motion.div
        animate={{ x: '-50%' }}
        transition={{ duration: 28, repeat: Infinity, ease: 'linear' }}
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 'clamp(48px, 6vw, 80px)',
          whiteSpace: 'nowrap',
        }}
      >
        {CLIENTS.map((name, i) => (
          <span
            key={i}
            style={{
              fontFamily:    'var(--font-body)',
              fontSize:      'clamp(0.6rem, 0.85vw, 0.72rem)',
              fontWeight:    500,
              letterSpacing: '0.28em',
              textTransform: 'uppercase',
              color:         'var(--color-text-muted)',
              flexShrink:    0,
            }}
          >
            {name}
          </span>
        ))}
      </motion.div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   ABOUT
══════════════════════════════════════════════════════════════ */

export function About() {
  const sectionRef      = useRef<HTMLElement>(null);

  // Image reveal refs
  const imageRef        = useRef<HTMLDivElement>(null);

  // Pinned editorial refs
  const editorialOuter  = useRef<HTMLDivElement>(null); // 440vh wrapper
  const editorialInner  = useRef<HTMLDivElement>(null); // 100svh sticky

  // Elements inside the sticky frame
  const eyebrowRef      = useRef<HTMLDivElement>(null);
  const headline1Ref    = useRef<HTMLSpanElement>(null);
  const headline2Ref    = useRef<HTMLSpanElement>(null);
  const goldRuleRef     = useRef<HTMLSpanElement>(null);
  const para1Ref        = useRef<HTMLParagraphElement>(null);
  const para2Ref        = useRef<HTMLParagraphElement>(null);
  const pillar1Ref      = useRef<HTMLDivElement>(null);
  const pillar2Ref      = useRef<HTMLDivElement>(null);
  const pillar3Ref      = useRef<HTMLDivElement>(null);
  const ctaRef          = useRef<HTMLAnchorElement>(null);
  const bgGlowRef       = useRef<HTMLDivElement>(null);

  const marqueeRef      = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {

      /* ── Part 1: Image clip-path reveal ─────────────────── */
      if (imageRef.current) {
        gsap.fromTo(
          imageRef.current,
          { clipPath: 'inset(22% 8% 22% 8%)' },
          {
            clipPath: 'inset(0% 0% 0% 0%)',
            ease: 'power2.inOut',
            scrollTrigger: {
              trigger: imageRef.current,
              start: 'top 82%',
              end:   'bottom 24%',
              scrub: 1.6,
            },
          }
        );

        const img = imageRef.current.querySelector('img');
        if (img) {
          gsap.fromTo(img,
            { scale: 1.12, y: '3%' },
            {
              scale: 1.0, y: '-3%', ease: 'none',
              scrollTrigger: {
                trigger: imageRef.current,
                start: 'top bottom',
                end:   'bottom top',
                scrub: true,
              },
            }
          );
        }
      }

      /* ── Part 2: Pinned editorial — phased scroll reveal ─── */
      if (editorialOuter.current && editorialInner.current) {

        // Set all elements to hidden state before timeline runs
        gsap.set(eyebrowRef.current,   { y: 28, opacity: 0, filter: 'blur(5px)' });
        gsap.set(headline1Ref.current, { y: 36, opacity: 0, filter: 'blur(6px)' });
        gsap.set(headline2Ref.current, { y: 36, opacity: 0, filter: 'blur(6px)', scale: 0.97 });
        gsap.set(goldRuleRef.current,  { scaleX: 0, opacity: 0, transformOrigin: 'left center' });
        gsap.set(para1Ref.current,     { y: 28, opacity: 0, filter: 'blur(4px)' });
        gsap.set(para2Ref.current,     { y: 28, opacity: 0, filter: 'blur(4px)' });
        gsap.set(pillar1Ref.current,   { y: 44, opacity: 0, filter: 'blur(5px)' });
        gsap.set(pillar2Ref.current,   { y: 44, opacity: 0, filter: 'blur(5px)' });
        gsap.set(pillar3Ref.current,   { y: 44, opacity: 0, filter: 'blur(5px)' });
        gsap.set(ctaRef.current,       { y: 18, opacity: 0 });
        gsap.set(bgGlowRef.current,    { opacity: 0 });

        /*
         * Timeline normalised to the 340vh of active scroll.
         * Outer wrapper is 440vh. Sticky frame is 100svh.
         * Active scroll = 440 - 100 = 340vh.
         *
         * ScrollTrigger: start 'top top' → end 'bottom bottom'
         * On a 440vh outer div:
         *   bottom of outer hits bottom of viewport
         *   when scroll = offsetTop + 440vh - 100vh = offsetTop + 340vh ✓
         */
        const tl = gsap.timeline({
          scrollTrigger: {
            trigger: editorialOuter.current,
            start: 'top top',
            end:   'bottom bottom',
            scrub: 1.4,
          },
        });

        // Total duration we assign = 10 units → maps to 340vh of scroll
        // We'll use addLabel to set positions

        tl
          // ── Phase A (0–18%): Eyebrow ─────────────────────
          .to(bgGlowRef.current, {
            opacity: 1, duration: 0.2, ease: 'none',
          }, 0)
          .to(eyebrowRef.current, {
            y: 0, opacity: 1, filter: 'blur(0px)', duration: 0.28, ease: 'power2.out',
          }, 0.08)

          // ── Phase B (14–32%): Headline line 1 ────────────
          .to(headline1Ref.current, {
            y: 0, opacity: 1, filter: 'blur(0px)', duration: 0.32, ease: 'power3.out',
          }, 0.22)

          // ── Phase C (26–44%): Headline line 2 — the punchline ─
          // scale adds weight: arrives slightly bigger, settles to normal
          .to(headline2Ref.current, {
            y: 0, opacity: 1, filter: 'blur(0px)', scale: 1.0, duration: 0.34, ease: 'power3.out',
          }, 0.36)

          // ── Phase D (40–56%): Gold rule extends ──────────
          .to(goldRuleRef.current, {
            scaleX: 1, opacity: 0.7, duration: 0.28, ease: 'power2.inOut',
          }, 0.48)

          // ── Phase E (52–66%): Body paragraph 1 ───────────
          .to(para1Ref.current, {
            y: 0, opacity: 1, filter: 'blur(0px)', duration: 0.28, ease: 'power2.out',
          }, 0.58)

          // ── Phase F (62–74%): Body paragraph 2 ───────────
          .to(para2Ref.current, {
            y: 0, opacity: 1, filter: 'blur(0px)', duration: 0.26, ease: 'power2.out',
          }, 0.70)

          // ── Phase G (70–80%): Pillar 01 ──────────────────
          .to(pillar1Ref.current, {
            y: 0, opacity: 1, filter: 'blur(0px)', duration: 0.22, ease: 'power3.out',
          }, 0.78)

          // ── Phase H (78–87%): Pillar 02 ──────────────────
          .to(pillar2Ref.current, {
            y: 0, opacity: 1, filter: 'blur(0px)', duration: 0.22, ease: 'power3.out',
          }, 0.84)

          // ── Phase I (85–94%): Pillar 03 ──────────────────
          .to(pillar3Ref.current, {
            y: 0, opacity: 1, filter: 'blur(0px)', duration: 0.22, ease: 'power3.out',
          }, 0.90)

          // ── Phase J (91–100%): CTA ────────────────────────
          .to(ctaRef.current, {
            y: 0, opacity: 1, duration: 0.18, ease: 'power2.out',
          }, 0.95);
      }

      /* ── Part 3: Marquee fade ──────────────────────────── */
      if (marqueeRef.current) {
        gsap.from(marqueeRef.current, {
          opacity: 0, duration: 1.0, ease: 'power2.out',
          scrollTrigger: {
            trigger: marqueeRef.current,
            start: 'top 88%',
            toggleActions: 'play none none none',
          },
        });
      }

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  /* ── Render ───────────────────────────────────────────────── */
  return (
    <section
      id="about"
      ref={sectionRef}
      style={{
        position: 'relative',
        background: 'var(--color-bg)',
        /*
         * CRITICAL: overflow: hidden breaks position: sticky on children.
         * The editorial pinned section needs sticky to work — never use
         * overflow: hidden on a parent of a sticky element.
         * overflow: clip is visually equivalent but doesn't create a scroll
         * container, so sticky children remain functional.
         */
        overflow: 'clip',
      }}
    >
      {/* Dark → light transition bridge
          Blends the black Statement section into the cream About section.
          Without this the cut from #070605 → #F7F5F1 is jarring.
          This gradient overlays the top of About, fading the darkness away. */}
      <div
        aria-hidden
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: '220px',
          background: 'linear-gradient(to bottom, #070605 0%, rgba(7,6,5,0.55) 40%, transparent 100%)',
          pointerEvents: 'none',
          zIndex: 2,
        }}
      />
      {/* Subtle grid texture */}
      <div
        aria-hidden
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `
            linear-gradient(rgba(197,160,89,0.025) 1px, transparent 1px),
            linear-gradient(90deg, rgba(197,160,89,0.025) 1px, transparent 1px)
          `,
          backgroundSize: '64px 64px',
          pointerEvents: 'none',
          zIndex: 0,
        }}
      />

      {/* ══════════════════════════════════════════════════════
          PART 1 — IMAGE REVEAL
          Full-width clip-path expansion on scroll.
          The visual moment before the words earn their place.
      ════════════════════════════════════════════════════════ */}
      <div
        style={{
          padding: 'clamp(80px, 9vw, 120px) clamp(20px, 4vw, 64px) 0',
          position: 'relative',
          zIndex: 1,
        }}
      >
        {/* Eyebrow above image */}
        <motion.div
          className="flex items-center gap-4 mb-8"
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.88, ease: [0.22, 1, 0.36, 1] }}
        >
          <span style={{ display: 'block', height: '1px', width: '36px', background: 'var(--color-accent-1)', opacity: 0.75 }} />
          <span style={{ fontSize: '0.66rem', letterSpacing: '0.34em', textTransform: 'uppercase', fontFamily: 'var(--font-body)', fontWeight: 400, color: 'var(--color-accent-1)' }}>
            About Ghaim
          </span>
        </motion.div>

        {/* Clip-path image container */}
        <div
          ref={imageRef}
          style={{
            width: '100%',
            height: 'clamp(280px, 48vw, 620px)',
            overflow: 'hidden',
            position: 'relative',
          }}
        >
          <img
            src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=2000&auto=format&fit=crop&q=85"
            alt="GHAIM luxury event — grand ballroom setup"
            style={{ width: '100%', height: '100%', objectFit: 'cover', transformOrigin: 'center center' }}
          />
          {/* Fade to page bg at bottom */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(to bottom, transparent 55%, rgba(247,245,241,0.60) 100%)',
              pointerEvents: 'none',
            }}
          />
          {/* Image caption */}
          <div style={{ position: 'absolute', bottom: '20px', left: '24px', display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ display: 'block', width: '24px', height: '1px', background: 'rgba(197,160,89,0.7)' }} />
            <span style={{ fontSize: '0.6rem', letterSpacing: '0.24em', textTransform: 'uppercase', fontFamily: 'var(--font-body)', color: 'rgba(255,255,255,0.65)' }}>
              Atlantis The Palm · 2024
            </span>
          </div>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════
          PART 2 — PINNED EDITORIAL SCENE
          440vh outer wrapper. 100svh sticky inner.
          Active scroll range: ~340vh. Everything is earned.
      ════════════════════════════════════════════════════════ */}
      <div
        ref={editorialOuter}
        style={{ height: '440vh', position: 'relative' }}
      >
        {/* 100svh sticky frame — never moves until parent exhausts */}
        <div
          ref={editorialInner}
          style={{
            position: 'sticky',
            top: 0,
            height: '100svh',
            minHeight: '600px',
            overflow: 'hidden',
            background: 'var(--color-bg)',
            display: 'flex',
            alignItems: 'center',
          }}
        >
          {/* Subtle background glow — warms up as content reveals */}
          <div
            ref={bgGlowRef}
            aria-hidden
            style={{
              position: 'absolute',
              top: '40%',
              left: '0%',
              width: '55%',
              height: '120%',
              background: 'radial-gradient(ellipse at 30% 50%, rgba(197,160,89,0.055) 0%, transparent 65%)',
              pointerEvents: 'none',
              opacity: 0,
            }}
          />

          {/* Inner content: left headline / right content */}
          <div
            className="about-editorial-scene"
            style={{
              position: 'relative',
              zIndex: 1,
              width: '100%',
              padding: '0 clamp(20px, 5vw, 80px)',
              display: 'grid',
              gridTemplateColumns: '1fr',
              gap: 'clamp(40px, 5vw, 80px)',
              alignItems: 'start',
            }}
          >

            {/* ── LEFT: Headline ─────────────────────────────────
             *  Sticks to its position while the right side fills in.
             *  Two-line structure. Line 2 is the punchline.
            ────────────────────────────────────────────────── */}
            <div
              className="about-left-col"
              style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}
            >
              {/* Eyebrow */}
              <div
                ref={eyebrowRef}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '14px',
                  opacity: 0,
                }}
              >
                <span style={{ display: 'block', height: '1px', width: '28px', background: 'var(--color-accent-1)', opacity: 0.7 }} />
                <span
                  style={{
                    fontSize: '0.64rem',
                    letterSpacing: '0.32em',
                    textTransform: 'uppercase',
                    fontFamily: 'var(--font-body)',
                    fontWeight: 400,
                    color: 'var(--color-accent-1)',
                  }}
                >
                  Our Approach
                </span>
              </div>

              {/* Headline — two-phase reveal */}
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(2.6rem, 5.2vw, 5.8rem)',
                  fontWeight: 300,
                  lineHeight: 1.02,
                  letterSpacing: '-0.024em',
                  color: 'var(--color-text)',
                }}
              >
                {/* Line 1: arrives first */}
                <span
                  ref={headline1Ref}
                  style={{ display: 'block', opacity: 0 }}
                >
                  Where Vision Meets
                </span>

                {/* Line 2: the punchline — arrives with scale, lands harder */}
                <span
                  ref={headline2Ref}
                  style={{
                    display: 'block',
                    opacity: 0,
                    fontStyle: 'italic',
                    color: 'var(--color-accent-1)',
                  }}
                >
                  Flawless Execution.
                </span>
              </h2>

              {/* Gold rule — extends after headline settles */}
              <span
                ref={goldRuleRef}
                style={{
                  display: 'block',
                  width: 'clamp(40px, 5vw, 64px)',
                  height: '1px',
                  background: 'linear-gradient(to right, var(--color-accent-1), transparent)',
                  opacity: 0,
                  transformOrigin: 'left center',
                }}
              />
            </div>

            {/* ── RIGHT: Content phases ───────────────────────────
             *  Paragraphs appear first. Then pillars one by one.
             *  Then CTA. Nothing competes with the headline.
            ────────────────────────────────────────────────── */}
            <div
              className="about-right-col"
              style={{ display: 'flex', flexDirection: 'column', gap: 'clamp(20px, 3vw, 36px)' }}
            >
              {/* Body paragraph 1 */}
              <p
                ref={para1Ref}
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'clamp(0.875rem, 1.15vw, 0.98rem)',
                  fontWeight: 300,
                  lineHeight: 1.88,
                  color: 'var(--color-text-mid)',
                  maxWidth: '500px',
                  opacity: 0,
                }}
              >
                GHAIM has spent over a decade shaping the most prestigious
                corporate events across the Gulf. We work exclusively with
                organisations that demand the highest standards — in venue,
                in service, in lasting impression.
              </p>

              {/* Body paragraph 2 */}
              <p
                ref={para2Ref}
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'clamp(0.875rem, 1.15vw, 0.98rem)',
                  fontWeight: 300,
                  lineHeight: 1.88,
                  color: 'var(--color-text-muted)',
                  maxWidth: '460px',
                  opacity: 0,
                }}
              >
                Our approach is quiet, deliberate, and precise. We do not
                measure success in headcount — we measure it in the
                conversations that happen the day after.
              </p>

              {/* Philosophy pillars — appear one by one.
                  NOT a grid. A sequence. Philosophy unfolding. */}
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 'clamp(16px, 2vw, 24px)',
                }}
              >
                {/* Pillar 01 */}
                <div
                  ref={pillar1Ref}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '10px',
                    paddingTop: '22px',
                    borderTop: '1px solid var(--color-accent-3)',
                    opacity: 0,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: '12px' }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: '0.7rem', fontWeight: 300, letterSpacing: '0.1em', color: 'var(--color-text-muted)' }}>
                      01
                    </span>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1rem, 1.55vw, 1.3rem)', fontWeight: 300, fontStyle: 'italic', letterSpacing: '-0.01em', color: 'var(--color-text)' }}>
                      A quiet approach.
                    </span>
                  </div>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: 'clamp(0.82rem, 1vw, 0.88rem)', fontWeight: 300, lineHeight: 1.82, color: 'var(--color-text-muted)', maxWidth: '420px' }}>
                    We don't seek attention for ourselves. The event is the statement. Our role is invisible architecture — the reason everything feels inevitable.
                  </p>
                </div>

                {/* Pillar 02 */}
                <div
                  ref={pillar2Ref}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '10px',
                    paddingTop: '22px',
                    borderTop: '1px solid var(--color-accent-3)',
                    opacity: 0,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: '12px' }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: '0.7rem', fontWeight: 300, letterSpacing: '0.1em', color: 'var(--color-text-muted)' }}>
                      02
                    </span>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1rem, 1.55vw, 1.3rem)', fontWeight: 300, fontStyle: 'italic', letterSpacing: '-0.01em', color: 'var(--color-text)' }}>
                      Precision over performance.
                    </span>
                  </div>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: 'clamp(0.82rem, 1vw, 0.88rem)', fontWeight: 300, lineHeight: 1.82, color: 'var(--color-text-muted)', maxWidth: '420px' }}>
                    Execution is not measured in headcount or decibels. It's measured in the quality of conversation the morning after.
                  </p>
                </div>

                {/* Pillar 03 */}
                <div
                  ref={pillar3Ref}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '10px',
                    paddingTop: '22px',
                    borderTop: '1px solid var(--color-accent-3)',
                    opacity: 0,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: '12px' }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: '0.7rem', fontWeight: 300, letterSpacing: '0.1em', color: 'var(--color-text-muted)' }}>
                      03
                    </span>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1rem, 1.55vw, 1.3rem)', fontWeight: 300, fontStyle: 'italic', letterSpacing: '-0.01em', color: 'var(--color-text)' }}>
                      Legacy over landmark.
                    </span>
                  </div>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: 'clamp(0.82rem, 1vw, 0.88rem)', fontWeight: 300, lineHeight: 1.82, color: 'var(--color-text-muted)', maxWidth: '420px' }}>
                    Any venue can impress once. We design experiences that compound — that become reference points in the memory of everyone in the room.
                  </p>
                </div>
              </div>

              {/* CTA — last thing to arrive. Micro-interaction on hover. */}
              <motion.a
                ref={ctaRef}
                href="#work"
                className="flex items-center gap-3"
                style={{
                  fontSize: '0.68rem',
                  letterSpacing: '0.2em',
                  textTransform: 'uppercase',
                  fontFamily: 'var(--font-body)',
                  fontWeight: 500,
                  color: 'var(--color-accent-1)',
                  width: 'fit-content',
                  opacity: 0,
                  position: 'relative',
                  paddingBottom: '3px',
                  textDecoration: 'none',
                }}
                whileHover={{ x: 6 }}
                transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              >
                {/* Underline grows on hover — not just a link, a moment */}
                <motion.span
                  style={{
                    position: 'absolute',
                    bottom: 0,
                    left: 0,
                    height: '1px',
                    background: 'var(--color-accent-1)',
                    transformOrigin: 'left center',
                  }}
                  initial={{ scaleX: 0 }}
                  whileHover={{ scaleX: 1 }}
                  transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1], delay: 0.05 }}
                />
                <span>View Our Work</span>
                {/* Arrow slides forward on hover */}
                <motion.span
                  style={{ display: 'flex', alignItems: 'center' }}
                  whileHover={{ x: 3 }}
                  transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1], delay: 0.08 }}
                >
                  <svg width="20" height="10" viewBox="0 0 20 10" fill="none">
                    <path d="M1 5h18M14 1l5 4-5 4" stroke="currentColor" strokeWidth="0.85" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </motion.span>
              </motion.a>
            </div>

          </div>{/* /editorial-scene grid */}
        </div>{/* /sticky frame */}

        {/* Responsive layout for the editorial scene */}
        <style>{`
          .about-editorial-scene {
            grid-template-columns: 1fr !important;
          }
          @media (min-width: 900px) {
            .about-editorial-scene {
              grid-template-columns: 45fr 55fr !important;
              align-items: center !important;
            }
            .about-left-col {
              position: relative;
            }
          }
        `}</style>

      </div>{/* /editorial outer 440vh */}

      {/* ══════════════════════════════════════════════════════
          PART 3 — CLIENT MARQUEE
          Appears after the pin releases. Quiet, continuous.
      ════════════════════════════════════════════════════════ */}
      <div
        ref={marqueeRef}
        style={{
          position: 'relative',
          zIndex: 1,
          borderTop:    '1px solid var(--color-accent-3)',
          borderBottom: '1px solid var(--color-accent-3)',
          padding: 'clamp(16px, 2vw, 22px) 0',
          overflow: 'hidden',
        }}
      >
        {/* "Trusted by" label */}
        <div
          style={{
            position: 'absolute',
            left: 'clamp(20px, 4vw, 64px)',
            top: '50%',
            transform: 'translateY(-50%)',
            zIndex: 2,
            display: 'flex',
            alignItems: 'center',
            gap: '14px',
            background: 'var(--color-bg)',
            paddingRight: '12px',
          }}
        >
          <span style={{ fontSize: '0.58rem', letterSpacing: '0.28em', textTransform: 'uppercase', fontFamily: 'var(--font-body)', color: 'var(--color-text-muted)', whiteSpace: 'nowrap' }}>
            Trusted by
          </span>
          <span style={{ display: 'block', width: '32px', height: '1px', background: 'linear-gradient(to right, rgba(197,160,89,0.5), transparent)' }} />
        </div>

        <div style={{ paddingLeft: 'clamp(120px, 13vw, 180px)' }}>
          <LogoMarquee />
        </div>
      </div>

      {/* Mobile overrides: no pin behavior side effects on small screens */}
      <style>{`
        @media (max-width: 640px) {
          /* Ensure pillars aren't too cramped on mobile */
          .about-editorial-scene > div {
            gap: 28px !important;
          }
        }
        /* Reduce motion */
        @media (prefers-reduced-motion: reduce) {
          .about-editorial-scene * {
            opacity: 1 !important;
            transform: none !important;
            filter: none !important;
          }
        }
      `}</style>

    </section>
  );
}
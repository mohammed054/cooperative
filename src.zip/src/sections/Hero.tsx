/**
 * Hero — Scene 1  (REWRITTEN)
 * ───────────────────────────────────────────────────────────────
 * Critical fixes & upgrades:
 *
 *   FIX   — White gap: outer section carries background: '#060504'
 *            so the 100vh scroll-zone below the sticky frame is never cream.
 *
 *   UPGRADE — Headline hierarchy:
 *     OLD: "We Craft / Extraordinary / Experiences." — 3 lines, no dominant
 *     NEW: "Extraordinary" italic gold (dominant word, full scale)
 *          "Experiences."  normal weight (landing)
 *          "Crafted with precision." — small italic below — supports, doesn't compete
 *
 *   UPGRADE — Gradient system: left vignette strengthened to 0.75 opacity.
 *             Grounds text. Kills the "video just playing" problem.
 *
 *   UPGRADE — Scroll exit adds brightness↓ + blur↑ to video.
 *             The world dims as you leave the scene. Cinematic.
 *
 *   UPGRADE — Primary CTA: glass treatment with inner glow, slow fill from left,
 *             border brightens AFTER background fills (lagged color shift).
 *
 *   UPGRADE — Composition: content pushed harder left, tighter vertical axis,
 *             controlled asymmetry. Video subject owns the right.
 */

import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

/* ── Word split helper ───────────────────────────────────────── */

function WordLine({
  words,
  italic = false,
  accent = false,
}: {
  words: string[];
  italic?: boolean;
  accent?: boolean;
}) {
  return (
    <>
      {words.map((word, i) => (
        <span
          key={i}
          style={{ display: 'inline-block', overflow: 'hidden', verticalAlign: 'bottom' }}
        >
          <span
            className="hero-word"
            style={{
              display: 'inline-block',
              fontStyle: italic ? 'italic' : 'normal',
              color: accent ? 'var(--color-accent-1)' : 'inherit',
            }}
          >
            {word}{'\u00a0'}
          </span>
        </span>
      ))}
    </>
  );
}

/* ── Corner ornament ─────────────────────────────────────────── */

function CornerOrnament({ position }: { position: 'tl' | 'tr' | 'bl' | 'br' }) {
  const pos = {
    tl: 'top-7 left-7 rotate-0',
    tr: 'top-7 right-7 rotate-90',
    bl: 'bottom-7 left-7 -rotate-90',
    br: 'bottom-7 right-7 rotate-180',
  }[position];

  return (
    <div
      className={`hero-ornament absolute ${pos} w-7 h-7 pointer-events-none hidden lg:block`}
      style={{ opacity: 0 }}
    >
      <svg viewBox="0 0 28 28" fill="none" className="w-full h-full">
        <path d="M2 26 L2 2 L26 2" stroke="#C5A059" strokeWidth="0.9" />
        <circle cx="2" cy="2" r="1.4" fill="#C5A059" opacity="0.8" />
      </svg>
    </div>
  );
}

/* ── Stat item ───────────────────────────────────────────────── */

function StatItem({ value, label }: { value: string; label: string }) {
  return (
    <div className="hero-stat flex flex-col items-center md:items-start gap-1" style={{ opacity: 0 }}>
      <span
        style={{
          fontFamily: 'var(--font-display)',
          fontSize: 'clamp(1.55rem, 2.8vw, 2.25rem)',
          fontWeight: 300,
          letterSpacing: '-0.02em',
          lineHeight: 1,
          color: '#FFFFFF',
        }}
      >
        {value}
      </span>
      <span
        style={{
          fontSize: '0.62rem',
          letterSpacing: '0.24em',
          textTransform: 'uppercase',
          fontFamily: 'var(--font-body)',
          fontWeight: 400,
          color: 'rgba(255,255,255,0.52)',
        }}
      >
        {label}
      </span>
    </div>
  );
}

/* ── Glass CTA button — the physical object ──────────────────── */
/*
 * This replaces the generic Button component for the hero primary CTA.
 * Layers:
 *   1. Outer glow — expands on hover (atmosphere)
 *   2. Glass shell — backdrop-blur deepens on hover
 *   3. Fill sweep — slides from left (the "filling" motion)
 *   4. Border — brightens AFTER fill (lagged — text shift follows)
 *   5. Text — color shifts last (physical object sequence)
 */

function GlassButton({ children, href }: { children: React.ReactNode; href?: string }) {
  return (
    <motion.div
      style={{ position: 'relative', display: 'inline-block', cursor: 'pointer' }}
      whileHover="hover"
      initial="rest"
    >
      {/* Outer ambient glow */}
      <motion.span
        variants={{
          rest:  { opacity: 0, scale: 0.88 },
          hover: { opacity: 1,  scale: 1.05 },
        }}
        transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
        style={{
          position: 'absolute',
          inset: '-6px',
          borderRadius: '3px',
          background: 'radial-gradient(ellipse at center, rgba(197,160,89,0.16) 0%, transparent 72%)',
          pointerEvents: 'none',
          zIndex: 0,
        }}
      />

      {/* Glass shell */}
      <motion.span
        variants={{
          rest:  { background: 'rgba(255,255,255,0.04)' },
          hover: { background: 'rgba(255,255,255,0.08)' },
        }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        style={{
          position: 'absolute',
          inset: 0,
          backdropFilter: 'blur(10px)',
          WebkitBackdropFilter: 'blur(10px)',
          borderRadius: '2px',
          pointerEvents: 'none',
          zIndex: 1,
        }}
      />

      {/* Base border */}
      <span
        style={{
          position: 'absolute',
          inset: 0,
          border: '1px solid rgba(255,255,255,0.24)',
          borderRadius: '2px',
          pointerEvents: 'none',
          zIndex: 1,
        }}
      />

      {/* Fill sweep — slides from left on hover */}
      <motion.span
        variants={{
          rest:  { scaleX: 0, originX: 0 },
          hover: { scaleX: 1, originX: 0 },
        }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1], delay: 0.03 }}
        style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(to right, rgba(197,160,89,0.18), rgba(197,160,89,0.07))',
          borderRadius: '2px',
          pointerEvents: 'none',
          zIndex: 2,
        }}
      />

      {/* Border brightens after fill — lagged */}
      <motion.span
        variants={{
          rest:  { opacity: 0 },
          hover: { opacity: 1 },
        }}
        transition={{ duration: 0.38, delay: 0.16, ease: 'easeOut' }}
        style={{
          position: 'absolute',
          inset: 0,
          border: '1px solid rgba(197,160,89,0.58)',
          borderRadius: '2px',
          pointerEvents: 'none',
          zIndex: 3,
        }}
      />

      {/* Text layer — color shift last */}
      <motion.a
        href={href}
        variants={{
          rest:  { color: 'rgba(255,255,255,0.85)' },
          hover: { color: '#FFFFFF' },
        }}
        transition={{ duration: 0.3, delay: 0.18, ease: 'easeOut' }}
        style={{
          position: 'relative',
          zIndex: 4,
          display: 'inline-block',
          padding: 'clamp(12px, 1.4vw, 14px) clamp(28px, 3.2vw, 42px)',
          fontSize: '0.74rem',
          letterSpacing: '0.24em',
          textTransform: 'uppercase',
          fontFamily: 'var(--font-body)',
          fontWeight: 500,
          textDecoration: 'none',
        }}
      >
        {children}
      </motion.a>
    </motion.div>
  );
}

/* ══════════════════════════════════════════════════════════════
   HERO
══════════════════════════════════════════════════════════════ */

export function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const statsRef   = useRef<HTMLDivElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const videoRef   = useRef<HTMLVideoElement>(null);

  /* ── Load sequence ───────────────────────────────────────────
     Order: dominant headline words → sub-statement → eyebrow
            → body copy → CTA → stats → decorative
     "Extraordinary" lands first and hardest. Everything serves it.
  ─────────────────────────────────────────────────────────── */
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.set('.hero-word',          { y: 90, opacity: 0 });
      gsap.set('.hero-sub-statement', { y: 22, opacity: 0 });
      gsap.set('.hero-eyebrow',       { y: 24, opacity: 0 });
      gsap.set('.hero-sub',           { y: 20, opacity: 0 });
      gsap.set('.hero-cta',           { y: 16, opacity: 0 });
      gsap.set('.hero-stat',          { y: 18, opacity: 0 });
      gsap.set('.hero-ornament',      { opacity: 0 });
      gsap.set('.hero-side',          { opacity: 0 });
      gsap.set('.hero-pulse',         { opacity: 0, y: 10 });

      const tl = gsap.timeline({ delay: 0.42 });

      tl
        // 1 — Dominant words: hard, fast-in with power4
        .to('.hero-word', {
          y: 0, opacity: 1, duration: 1.25, stagger: 0.058, ease: 'power4.out',
        })
        // 2 — Sub-statement: softer, italic, arrives just after headline settles
        .to('.hero-sub-statement', {
          y: 0, opacity: 1, duration: 1.0, ease: 'power3.out',
        }, '-=0.58')
        // 3 — Eyebrow: despite being visually above the headline, it reads last
        .to('.hero-eyebrow', {
          y: 0, opacity: 1, duration: 0.88, ease: 'power3.out',
        }, '-=0.78')
        // 4 — Body copy
        .to('.hero-sub', {
          y: 0, opacity: 1, duration: 0.88, ease: 'power3.out',
        }, '-=0.58')
        // 5 — CTA
        .to('.hero-cta', {
          y: 0, opacity: 1, duration: 0.8, ease: 'power3.out',
        }, '-=0.52')
        // 6 — Stats rise from bottom
        .to('.hero-stat', {
          y: 0, opacity: 1, stagger: 0.12, duration: 0.78, ease: 'power2.out',
        }, '-=0.52')
        // 7 — Decorative finish
        .to('.hero-ornament', { opacity: 0.5, duration: 0.8, ease: 'power2.out' }, '-=0.56')
        .to('.hero-side',     { opacity: 1,   duration: 0.8, ease: 'power2.out' }, '<')
        .to('.hero-pulse',    { opacity: 1, y: 0, duration: 0.75, ease: 'power2.out' }, '-=0.4');
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  /* ── Scroll exit — parallax exit within single 100vh section ──
     No sticky+oversized-outer needed. Hero is exactly 100vh.
     Content drifts up, video breathes out, overlay deepens.
     All animations play within the natural scroll of the section.
  ─────────────────────────────────────────────────────────── */
  useEffect(() => {
    const ctx = gsap.context(() => {
      /* Content: drifts upward as section scrolls */
      gsap.to(contentRef.current, {
        y: -55, opacity: 0, ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: 0.7,
        },
      });
      gsap.to(statsRef.current, {
        y: -28, opacity: 0, ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: 0.5,
        },
      });
      /* Overlay: darkens progressively */
      gsap.to(overlayRef.current, {
        opacity: 0.92, ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: 0.8,
        },
      });
      /* Video: subtle scale + dim */
      gsap.to(videoRef.current, {
        scale: 1.07,
        filter: 'brightness(0.5) blur(2px)',
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: 1.0,
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  /* ── Render ──────────────────────────────────────────────── */
  return (
    /*
     * CLEAN 100vh — no sticky+oversized-outer, no dead zone.
     * The extra scroll space was causing 100vh of black air between
     * Hero and Statement. Now Hero is exactly one viewport tall.
     * Scroll exit animations run via parallax within this 100vh.
     */
    <section
      ref={sectionRef}
      id="hero"
      style={{
        height: '100svh',
        minHeight: '660px',
        position: 'relative',
        overflow: 'hidden',
        background: '#060504',
      }}
    >
        {/* ══ VIDEO ════════════════════════════════════════════ */}
        <video
          ref={videoRef}
          autoPlay
          muted
          loop
          playsInline
          poster="/images/hero-poster.jpg"
          style={{
            position: 'absolute',
            inset: 0,
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            transformOrigin: 'center center',
            willChange: 'transform, filter',
          }}
        >
          <source src="/background.mp4" type="video/mp4" />
          <source src="/videos/hero.webm" type="video/webm" />
        </video>

        {/* ══ GRADIENTS ══════════════════════════════════════
            Left: strong, asymmetric — text lives here.
            Top/bottom: atmospheric — keeps the frame dark.
        ════════════════════════════════════════════════════ */}

        {/* Left anchor gradient — the primary compositional tool */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'linear-gradient(to right, rgba(0,0,0,0.76) 0%, rgba(0,0,0,0.50) 32%, rgba(0,0,0,0.22) 58%, rgba(0,0,0,0.05) 100%)',
          }}
        />

        {/* Top / bottom atmospheric vignette */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: `linear-gradient(
              to bottom,
              rgba(6,5,4,0.50)  0%,
              rgba(6,5,4,0.10) 28%,
              rgba(6,5,4,0.14) 56%,
              rgba(6,5,4,0.68) 85%,
              rgba(6,5,4,0.88) 100%
            )`,
          }}
        />

        {/* Scroll-exit dark overlay */}
        <div
          ref={overlayRef}
          className="absolute inset-0 pointer-events-none"
          style={{ background: '#060504', opacity: 0 }}
        />

        {/* ══ DECORATIVE ══════════════════════════════════════ */}
        <CornerOrnament position="tl" />
        <CornerOrnament position="tr" />
        <CornerOrnament position="bl" />
        <CornerOrnament position="br" />

        <div
          className="hero-side absolute left-6 top-1/2 -translate-y-1/2 hidden lg:flex flex-col items-center gap-3 z-10"
          style={{ opacity: 0 }}
        >
          <span style={{ fontSize: '0.58rem', letterSpacing: '0.3em', textTransform: 'uppercase', writingMode: 'vertical-rl', fontFamily: 'var(--font-body)', fontWeight: 400, color: 'rgba(255,255,255,0.30)' }}>
            Est. 2018
          </span>
          <span style={{ width: '1px', height: '56px', background: 'linear-gradient(to bottom, rgba(197,160,89,0.55), transparent)' }} />
        </div>

        <div
          className="hero-side absolute right-6 top-1/2 -translate-y-1/2 hidden lg:flex flex-col items-center gap-3 z-10"
          style={{ opacity: 0 }}
        >
          <span style={{ width: '1px', height: '56px', background: 'linear-gradient(to bottom, transparent, rgba(197,160,89,0.45))' }} />
          <span style={{ fontSize: '0.58rem', letterSpacing: '0.3em', textTransform: 'uppercase', writingMode: 'vertical-rl', fontFamily: 'var(--font-body)', fontWeight: 400, color: 'rgba(255,255,255,0.28)' }}>
            Scroll
          </span>
        </div>

        {/* ══ MAIN CONTENT ════════════════════════════════════
            Pushed further left. Video subject owns the right.
            Text dominates its half. Controlled asymmetry.
        ════════════════════════════════════════════════════ */}
        <div
          ref={contentRef}
          className="relative z-10 h-full flex flex-col justify-center"
          style={{
            paddingLeft:  'clamp(32px, 7.5vw, 114px)',
            paddingRight: 'clamp(24px, 6vw, 80px)',
          }}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'clamp(18px, 2.6vw, 30px)', maxWidth: '660px' }}>

            {/* Eyebrow */}
            <div className="hero-eyebrow flex items-center gap-4" style={{ opacity: 0 }}>
              <span style={{ display: 'block', height: '1px', width: '36px', background: 'var(--color-accent-1)', opacity: 0.75 }} />
              <span style={{ fontSize: '0.66rem', letterSpacing: '0.34em', textTransform: 'uppercase', fontFamily: 'var(--font-body)', fontWeight: 400, color: 'var(--color-accent-1)' }}>
                Luxury Event Management
              </span>
            </div>

            {/* ── HEADLINE — Restructured hierarchy ─────────────
             *  "Extraordinary" = the dominant word. Gold italic. One word.
             *  "Experiences."  = the landing. Normal weight. One word.
             *  Eye sequence: Extraordinary → Experiences. → sub-statement.
             *  Three beats. No noise.
            ─────────────────────────────────────────────── */}
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(3.5rem, 8.5vw, 9.2rem)',
                fontWeight: 300,
                lineHeight: 0.92,
                letterSpacing: '-0.030em',
                color: '#F8F4EE',
              }}
            >
              {/* Line 1: The dominant word — italic, gold, unmissable */}
              <WordLine words={['Extraordinary']} italic accent />
              <br />
              {/* Line 2: The landing point */}
              <WordLine words={['Experiences.']} />
            </h1>

            {/* Sub-statement — reads like a caption to a painting.
                Tiny, italic, deliberate. Arrives after headline settles. */}
            <p
              className="hero-sub-statement"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(1.05rem, 1.65vw, 1.38rem)',
                fontStyle: 'italic',
                fontWeight: 300,
                letterSpacing: '0.005em',
                lineHeight: 1.42,
                color: 'rgba(255,255,255,0.44)',
                opacity: 0,
                marginTop: '-4px',
              }}
            >
              Crafted with precision.
            </p>

            {/* Supporting body copy */}
            <p
              className="hero-sub"
              style={{
                fontSize: 'clamp(0.875rem, 1.15vw, 0.96rem)',
                fontFamily: 'var(--font-body)',
                fontWeight: 300,
                lineHeight: 1.84,
                letterSpacing: '0.01em',
                color: 'rgba(255,255,255,0.50)',
                maxWidth: '375px',
                opacity: 0,
              }}
            >
              From intimate corporate retreats to landmark galas —
              every detail is an act of deliberate precision.
            </p>

            {/* CTA row */}
            <div
              className="hero-cta flex flex-wrap items-center gap-6 pt-1"
              style={{ opacity: 0 }}
            >
              <GlassButton href="#work">Explore Our Work</GlassButton>

              <motion.a
                href="#about"
                className="flex items-center gap-3"
                style={{
                  fontSize: '0.68rem',
                  letterSpacing: '0.2em',
                  textTransform: 'uppercase',
                  fontFamily: 'var(--font-body)',
                  fontWeight: 400,
                  color: 'rgba(255,255,255,0.42)',
                }}
                whileHover={{ x: 5, color: 'rgba(255,255,255,0.88)' }}
                transition={{ duration: 0.22 }}
              >
                <span>Our Story</span>
                <svg width="18" height="10" viewBox="0 0 18 10" fill="none">
                  <path d="M1 5h16M12 1l5 4-5 4" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </motion.a>
            </div>
          </div>
        </div>

        {/* ══ STATS BAR ══════════════════════════════════════ */}
        <div
          ref={statsRef}
          className="absolute bottom-10 z-10"
          style={{ left: 'clamp(32px, 7.5vw, 114px)', right: 'clamp(32px, 7.5vw, 114px)' }}
        >
          <div
            className="mb-7"
            style={{
              height: '1px',
              background: 'linear-gradient(to right, rgba(197,160,89,0.62), rgba(197,160,89,0.18), transparent)',
            }}
          />
          <div className="flex flex-row items-start justify-between md:justify-start md:gap-16">
            <StatItem value="200+" label="Events Delivered"    />
            <StatItem value="18"   label="Countries"           />
            <StatItem value="12+"  label="Years of Excellence" />
          </div>
        </div>

        {/* ══ SCROLL PULSE ══════════════════════════════════ */}
        <div
          className="hero-pulse absolute bottom-12 left-1/2 -translate-x-1/2 z-10 hidden md:flex flex-col items-center"
          style={{ opacity: 0 }}
        >
          <motion.span
            style={{ display: 'block', width: '1px', height: '44px', background: 'linear-gradient(to bottom, rgba(197,160,89,0.65), transparent)' }}
            animate={{ scaleY: [1, 0.35, 1], opacity: [0.7, 0.16, 0.7] }}
            transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
          />
        </div>

    </section>
  );
}
// Backward-compatible shim.
// Use `./OperationsSpineScene` for new imports.
export { OperationsSpineScene as default, OperationsSpineScene } from './OperationsSpineScene'
